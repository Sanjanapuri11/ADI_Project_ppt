import React,{useState} from 'react';
import {HiOutlineArrowNarrowRight} from 'react-icons/hi'
import axios from "axios";
import toast from "react-hot-toast";
import {useNavigate} from "react-router-dom"

const Reservation = () => {

    const [firstName, setfirstName] = useState("");
    const [lastName, setlastName] = useState("");
    const [email, setemail] = useState("");
    const [date, setdate] = useState("");
    const [time, settime] = useState("");
    const [phone, setphone] = useState(0);
    const navigate=useNavigate();

    const handleReservation = async (e)=>{
        e.preventDefault();
        try {
            const {data} = await axios.post("http://localhost:4000/api/v1/reservations/send",
            {firstName,lastName,email,phone,date,time},{
                headers:{
                    "Content-Type":"application/json"
                },
                withCredentials:true,
            }
            );
            toast.success(data.message);
            setfirstName("");
            setlastName("");
            setemail("");
            setdate("");
            settime("");
            setphone(0);
            navigate("/Success");
        } catch (error) {
            toast.error(error);
        }
    }

  return (
    <section className="reservation" id="reservation">
        <div className="container">
            <div className="banner">
                <img src="./reservation.png" alt="" />
            </div>
            <div className="banner">
                <div className="reservation_form_box">
                    <h1>MAKE A RESERVATION</h1>
                    <p>For Further Questions,Please Call</p>
                    <form >
                        <div>
                            <input type="text" placeholder='First Name' value={firstName} onChange={(e)=> setfirstName(e.target.value)}/>
                            <input type="text" placeholder='Last Name' value={lastName} onChange={(e)=> setlastName(e.target.value)}/>
                        </div>
                        <div>
                            <input type="date" placeholder='Date' value={date} onChange={(e)=>setdate(e.target.value)}/>
                            <input type="time" placeholder='Time' value={time} onChange={(e)=>settime(e.target.value)}/>
                        </div>
                        <div>
                            <input type="email" placeholder='Email' className='email_tag' value={email} onChange={(e)=>setemail(e.target.value)}/>
                            <input type="number" placeholder='Phone' value={phone} onChange={(e)=>setphone(e.target.value)}/>
                        </div>
                        <button type="submit" onClick={handleReservation}>
                            RESERVE NOW{" "} <span>
                                <HiOutlineArrowNarrowRight/>
                            </span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>
  )
}

export default Reservation