import React from 'react'
import {Link} from "react-router-dom";
import {HiOutlineArrowNarrowRight} from "react-icons/hi"

const About = () => {
  return (
    <>
        <section className='about' id='about'>
            <div className="container ">
                <div className="banner">
                    <div className="top">
                        <h1 className="heading">ABOUT US</h1>
                        <p>The only thing we're serious about is food.</p>
                    </div>
                    <p className="mid">
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Harum nisi excepturi dolores totam blanditiis, dignissimos suscipit accusantium itaque dolore et ab nobis obcaecati id! Dolorem nulla quae mollitia quidem laudantium inventore at impedit placeat sunt voluptatum, corrupti consequuntur sint natus molestiae est, quos qui minus. Reiciendis magni quam fugiat quisquam!
                    </p>
                    <Link to={"/"}>Explore Menu 
                        <span>
                            <HiOutlineArrowNarrowRight/>
                        </span> 
                    </Link>
                </div>
                <div className="banner">
                    <img src="/about.png" alt="about" />
                </div>
            </div>
        </section>
    </>
  )
}

export default About